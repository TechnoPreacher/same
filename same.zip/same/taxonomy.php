<?php
global $project_cat;
$tax_from_tax = $project_cat;
include 'portfolio.php';