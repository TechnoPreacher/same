<?php get_header(); ?>

	<section id="content">
		<h1>404!</h1>
	</section>

<?php get_footer(); ?>
